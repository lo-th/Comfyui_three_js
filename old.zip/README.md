# Comfyui_three_js
Custom node for ComfyUI to run three js

<img src="./js/assets/preview.png"/>